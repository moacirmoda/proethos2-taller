<?php

if (isset($_GET["url"])) {
	$url = str_replace(array(' '), array('%20'), $_GET["url"]);

	//$ext = strtolower(pathinfo($url, PATHINFO_EXTENSION));
	$partes = pathinfo($url);
	$name 	= $partes['basename'];
	$ext 	= strtolower($partes['extension']);
	$tipos 	= array("pdf","doc","docx","xls","xlsx","jpg","jpeg","png");
	if (in_array($ext, $tipos)) {
		$archivo = file_get_contents($url);
		//$archivo = file_get_contents("http://190.102.147.212:8081/scriptcase/file/doc/protocolo%201.docx");
		file_put_contents($name, $archivo);
		echo "Archivo: " . $name . " grabado correctamente";
	} else {
		echo "ERROR ";
		echo "<br/>Tipo de archivo no permitido.";
	}
} else {
	echo "ERROR";
}
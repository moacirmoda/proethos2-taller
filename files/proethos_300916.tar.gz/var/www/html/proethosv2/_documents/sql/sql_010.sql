insert into cep_action_permission 
	(
actionp_action, actionp_perfil, actionp_ativa
	)
values
	(
'015','#MEM',1
	)
_include
========

_include (Biblioteca sisDOC)

Biblioteca Char
ShowLink ($link, $type, $label, $target)
	Mostra link 
	
Biblioteca Debug
Enable DEBUG - Show Erros Mensage

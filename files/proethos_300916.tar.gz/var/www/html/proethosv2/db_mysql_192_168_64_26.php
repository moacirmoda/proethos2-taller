<?php
// This file is part of the ProEthos Software. 
// 
// Copyright 2013, PAHO. All rights reserved. You can redistribute it and/or modify
// ProEthos under the terms of the ProEthos License as published by PAHO, which
// restricts commercial use of the Software. 
// 
// ProEthos is distributed in the hope that it will be useful, but WITHOUT ANY
// WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
// PARTICULAR PURPOSE. See the ProEthos License for more details. 
// 
// You should have received a copy of the ProEthos License along with the ProEthos
// Software. If not, see
// https://raw.githubusercontent.com/bireme/proethos/master/LICENSE.txt

	
				$site='http://190.102.152.86/proethosv2/admin_committe.php';
				$institution_name='Comite de ética del Instituto Nacional de Salud - ProEthos';
				$institution_site='http://190.102.152.86/proethosv2/admin_committe.php';
				$institution_address='http://www.portal.ins.gob.pe/es/
Cápac Yupanqui 1400 - Jesús María';
				$institution_city='Lima';
				$institution_country='Peru';
				$institution_phone='7481111';
				
				$harvestig='1';
				$harvesting_key='';
				$institution_logo='';
				$admin_nome='ProethosINS';
				$admin_email='acondor@ins.gob.pe';
				$email_adm='acondor@ins.gob.pe';
				$committe='INS';
				
				$language='es';
				$commite_type='CEP';

				/* Screen - Config */
				$tab_max='98%';
				$charset='utf-8';
				
?>